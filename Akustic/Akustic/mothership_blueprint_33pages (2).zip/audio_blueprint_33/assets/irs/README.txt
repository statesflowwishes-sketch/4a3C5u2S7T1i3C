Lege hier deine Impulsantworten (IR/BRIR) ab. Beispiel: brir_cinema_wide.wav
